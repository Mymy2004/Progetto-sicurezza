import os, shutil
from openssl_api import OpenSSLWrapper

def setup():
    # Cartella root
    SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
    # Cartella dei Prodotti
    PRODOTTI_DIR = os.path.join(SCRIPT_DIR, "..", "Prodotti")

    # CA Unica "Super Partes" (Simula un ente come Aruba/InfoCert)
    CA_DIR = os.path.join(PRODOTTI_DIR, "Ente_Certificatore_Pubblico/local_ca")

    # Definisce le destinazioni per i certificati generati
    KEYS_MEDICO = os.path.join(PRODOTTI_DIR, "AziendaOspedaliera", "Chiavi_Medico")
    KEYS_CONS = os.path.join(PRODOTTI_DIR, "ConservatoreEsterno", "Chiavi_Conservatore")

    medici = ["Luigi_Verdi"]
    CONSERVATORE = "Responsabile_Conservazione"

    # Crea le cartelle di destinazione
    for d in [KEYS_MEDICO, KEYS_CONS]:
        os.makedirs(d, exist_ok=True)
    
    # Verifica l'esistenza della cartella XML per i file di input
    xml_prodotti = os.path.join(PRODOTTI_DIR, "AziendaOspedaliera", "XML")
    os.makedirs(xml_prodotti, exist_ok=True)
    
    # Copia i file XML originali se presenti nella cartella gemella
    xml_originali = os.path.join(SCRIPT_DIR, "..", "XML")
    if os.path.exists(xml_originali):
        for f in os.listdir(xml_originali):
            if f.endswith(".xml"):
                shutil.copy(os.path.join(xml_originali, f), xml_prodotti)
        print(f"File XML copiati da {xml_originali} a {xml_prodotti}")

    print(f"--- [SETUP] INIZIALIZZAZIONE PKI IN: {PRODOTTI_DIR} ---")

    # 1. Crea l'infrastruttura dell'Ente Certificatore
    if not os.path.exists(CA_DIR):
        print("Creazione dell'Ente Certificatore Fittizio in corso...")
        OpenSSLWrapper.create_ca(CA_DIR, "Root CA Pubblica Simulata")
    else:
        print(f"Root CA già esistente in {CA_DIR}.")

    # 2. Rilascia le chiavi ai Medici (Azienda Ospedaliera)
    for medico in medici:
        key_m = f"{KEYS_MEDICO}/{medico}_private.pem"
        csr_m = f"{KEYS_MEDICO}/{medico}.csr"
        cert_m = f"{KEYS_MEDICO}/{medico}.crt"

        # Controlla se esistono sia la chiave che il certificato finale
        if not (os.path.exists(key_m) and os.path.exists(cert_m)):
            print(f"Rilascio certificato per: {medico}...")
            OpenSSLWrapper.create_rsa_key(2048, key_m)
            OpenSSLWrapper.create_certificate_request(key_m, csr_m, medico)
            OpenSSLWrapper.sign_certificate(CA_DIR, csr_m, cert_m)
        else:
            print(f"Certificato già esistente e pronto per: {medico}.")

    # 3. Rilascia le chiavi al Conservatore
    key_c = f"{KEYS_CONS}/{CONSERVATORE}_private.pem"
    csr_c = f"{KEYS_CONS}/{CONSERVATORE}.csr"
    cert_c = f"{KEYS_CONS}/{CONSERVATORE}.crt"

    # Controlla se esistono sia la chiave che il certificato finale
    if not (os.path.exists(key_c) and os.path.exists(cert_c)):
        print(f"Rilascio certificato per: {CONSERVATORE}...")
        OpenSSLWrapper.create_rsa_key(2048, key_c)
        OpenSSLWrapper.create_certificate_request(key_c, csr_c, CONSERVATORE)
        OpenSSLWrapper.sign_certificate(CA_DIR, csr_c, cert_c)
    else:
        print(f"Certificato già esistente e pronto per: {CONSERVATORE}.")

    print("--- [SETUP] COMPLETATO ---")

    # 4. Generazione Chiave di Cifratura Storage (AIP)
    storage_key_path = os.path.join(PRODOTTI_DIR, "storage.key")
    if not os.path.exists(storage_key_path):
        print("Generazione della chiave di cifratura per lo storage...")
        # Genera una chiave casuale di 32 byte (256 bit) e la salva in formato esadecimale o binario
        # La libreria salva i byte così come sono.
        OpenSSLWrapper.create_symmetric_key(32, storage_key_path)
    else:
        print(f"Chiave di storage già esistente in {storage_key_path}.")

if __name__ == "__main__":
    setup()