import os, shutil, datetime, sys, subprocess

# --- 1. GESTIONE PERCORSI E AMBIENTI ---
SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
# Definisce la cartella radice del progetto
PROJECT_ROOT = os.path.dirname(SCRIPT_DIR)
BASE_PRODOTTI = os.path.join(PROJECT_ROOT, "Prodotti")
ORIGINAL_XML_DIR = os.path.join(PROJECT_ROOT, "XML")

# Crea la cartella base per i prodotti se non esiste
os.makedirs(BASE_PRODOTTI, exist_ok=True)
sys.path.append(SCRIPT_DIR)
from openssl_api import OpenSSLWrapper

# Definisce la struttura dell'Azienda Ospedaliera
AO_BASE = os.path.join(BASE_PRODOTTI, "AziendaOspedaliera")
XML_IN_AO = os.path.join(AO_BASE, "XML")
KEYS_AO = os.path.join(AO_BASE, "Chiavi_Medico")
RICEVUTE_AO = os.path.join(AO_BASE, "Ricevute")

# Definisce la struttura del Conservatore Esterno
CE_BASE = os.path.join(BASE_PRODOTTI, "ConservatoreEsterno")
INBOX_CE = os.path.join(CE_BASE, "Ricezione_PdV")
AIP_CE   = os.path.join(CE_BASE, "Pacchetti_Conservazione")
KEYS_CE  = os.path.join(CE_BASE, "Chiavi_Conservatore")

# Imposta identità e parametri di storage
MEDICO = "Luigi_Verdi"
CONSERV = "Responsabile_Conservazione"
STORAGE_PASSWORD = "SicurezzaStorage2026"
CA_CERT_PATH = os.path.join(BASE_PRODOTTI, "Ente_Certificatore_Pubblico", "local_ca", "certs", "ca.cert.pem")

# Crea le directory necessarie
for d in [XML_IN_AO, AIP_CE, RICEVUTE_AO, INBOX_CE]:
    os.makedirs(d, exist_ok=True)

print(f"=== AVVIO SISTEMA CONSERVAZIONE (TAR NATIVO) ===")

# Verifica l'esistenza della cartella sorgente
if not os.path.exists(ORIGINAL_XML_DIR):
    print(f"[ERRORE] Cartella sorgente originale non trovata in: {ORIGINAL_XML_DIR}")
    sys.exit(1)

# Copia i file XML originali nell'ambiente dell'Azienda Ospedaliera
for xml_file in [f for f in os.listdir(ORIGINAL_XML_DIR) if f.endswith(".xml")]:
    shutil.copy(os.path.join(ORIGINAL_XML_DIR, xml_file), os.path.join(XML_IN_AO, xml_file))

# Elabora ogni documento XML per la conservazione
for xml_file in os.listdir(XML_IN_AO):
    doc_id = xml_file.replace(".xml", "")
    xml_path = os.path.join(XML_IN_AO, xml_file)
    print(f"\n--- Documento: {xml_file} ---")

    # --- FASE 1: AZIENDA OSPEDALIERA (Produttore) ---
    tmp_ao = os.path.join(AO_BASE, f"tmp_pdv_{doc_id}")
    os.makedirs(tmp_ao, exist_ok=True)

    # Appone la firma digitale del medico (formato PKCS#7 / P7M)
    p7m_local = os.path.join(tmp_ao, f"{doc_id}_firma_medico.p7m")
    OpenSSLWrapper.envelop_signature_pkcs7(xml_path, os.path.join(KEYS_AO, f"{MEDICO}.crt"), os.path.join(KEYS_AO, f"{MEDICO}_private.pem"), p7m_local)

    # Genera i metadati strutturati secondo standard di conservazione
    with open(os.path.join(tmp_ao, "Metadati.xml"), "w") as f:
        metadata_content = f"""<?xml version="1.0" encoding="UTF-8"?>
<PacchettoArchiviazione xmlns="http://www.agid.gov.it/standards/metadata/preservation">
    <Intestazione>
        <IdentificativoUnico>{doc_id}</IdentificativoUnico>
        <Versione>1.0</Versione>
        <Oggetto>Prescrizione Medica Elettronica</Oggetto>
    </Intestazione>
    <Documento>
        <ProfiloDocumentale>
            <TipologiaDocumentale>Prescrizione</TipologiaDocumentale>
            <NomeFileOriginale>{xml_file}</NomeFileOriginale>
            <ImprontaInformatica algoritmo="SHA256">{OpenSSLWrapper.generate_hash(xml_path)}</ImprontaInformatica>
        </ProfiloDocumentale>
    </Documento>
    <SoggettoProduttore>
        <Denominazione>{MEDICO}</Denominazione>
        <EnteAppartenenza>Azienda Ospedaliera Simulata</EnteAppartenenza>
    </SoggettoProduttore>
    <Conservazione>
        <ResponsabileConservazione>{CONSERV}</ResponsabileConservazione>
        <SistemaConservazione>Sistema_Storage_Sicuro_2026</SistemaConservazione>
        <DataArchiviazione>{datetime.datetime.now().isoformat()}</DataArchiviazione>
    </Conservazione>
</PacchettoArchiviazione>
"""
        f.write(metadata_content)
    
    # Include il documento originale nel pacchetto temporaneo
    shutil.copy(xml_path, tmp_ao)

    # Crea il Pacchetto di Versamento (PdV) tramite comando tar
    pdv_tar_full = os.path.join(AO_BASE, f"PdV_{doc_id}.tar.gz")
    subprocess.run(["tar", "-czf", pdv_tar_full, "-C", tmp_ao, "."], check=True)
    shutil.rmtree(tmp_ao)

    # Invia il PdV al Conservatore Esterno
    pdv_in_ce = os.path.join(INBOX_CE, f"PdV_{doc_id}.tar.gz")
    shutil.move(pdv_tar_full, pdv_in_ce)
    print(f"    [AO -> CE] Pacchetto di Versamento (.tar.gz) inviato.")

    # --- FASE 2: CONSERVATORE ESTERNO ---
    # Genera la ricevuta di presa in carico (consegna)
    ric_1_local = os.path.join(CE_BASE, f"Ricevuta_1_CONSEGNA_{doc_id}.txt")
    with open(ric_1_local, "w") as f:
        f.write(f"RICEVUTA CONSEGNA\nDoc: {doc_id}\nData: {datetime.datetime.now()}")
    shutil.move(ric_1_local, os.path.join(RICEVUTE_AO, os.path.basename(ric_1_local)))

    # Estrae l'archivio ricevuto per la validazione
    extract_ce = os.path.join(CE_BASE, f"tmp_elaborazione_{doc_id}")
    os.makedirs(extract_ce, exist_ok=True)
    subprocess.run(["tar", "-xzf", pdv_in_ce, "-C", extract_ce], check=True)

    p7m_check = os.path.join(extract_ce, f"{doc_id}_firma_medico.p7m")
    xml_check = os.path.join(extract_ce, xml_file)

    # Verifica la validità della firma del medico tramite la CA pubblica
    if OpenSSLWrapper.verify_pkcs7_signature(p7m_check, content_file=xml_check, ca_file=CA_CERT_PATH if os.path.exists(CA_CERT_PATH) else None):
        print(f"    [CE] Firma valida. Creazione Pacchetto di Conservazione (PdC) e Cifratura...")

        # Appone il sigillo del conservatore (Controfirma PKCS#7)
        pdc_p7m = os.path.join(extract_ce, "PdC_Sigillo_Conservatore.p7m")
        OpenSSLWrapper.envelop_signature_pkcs7(p7m_check, os.path.join(KEYS_CE, f"{CONSERV}.crt"), os.path.join(KEYS_CE, f"{CONSERV}_private.pem"), pdc_p7m)

        # Crea il Pacchetto di Conservazione finale (PdC)
        pdc_tar_tmp = os.path.join(CE_BASE, f"PdC_Temp_{doc_id}.tar.gz")
        subprocess.run(["tar", "-czf", pdc_tar_tmp, "-C", extract_ce, "."], check=True)

        # Esegue la cifratura del pacchetto per la protezione a riposo (AIP)
        aip_cifrato = os.path.join(AIP_CE, f"PdC_{doc_id}.tar.gz.enc")
        OpenSSLWrapper.encrypt_file(pdc_tar_tmp, aip_cifrato, STORAGE_PASSWORD)
        os.remove(pdc_tar_tmp)

        # Genera la ricevuta finale di avvenuta archiviazione a norma
        ric_2_local = os.path.join(CE_BASE, f"Ricevuta_2_ARCHIVIAZIONE_{doc_id}.txt")
        with open(ric_2_local, "w") as f:
            f.write(f"RICEVUTA ARCHIVIAZIONE\nDoc: {doc_id}\nStato: A NORMA\nData: {datetime.datetime.now()}")
        shutil.move(ric_2_local, os.path.join(RICEVUTE_AO, os.path.basename(ric_2_local)))

        print(f"    [OK] Archiviazione completata con successo.")
    else:
        print(f"    [ERRORE] Firma corrotta o non valida per {doc_id}.")

    # Esegue la pulizia delle risorse temporanee
    shutil.rmtree(extract_ce)
    os.remove(pdv_in_ce)

print("\n=== PROCESSO COMPLETATO ===")
