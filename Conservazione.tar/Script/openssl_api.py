import subprocess
import os
import shutil
from typing import List, Optional

class OpenSSLWrapper:
    """
    A Python wrapper for OpenSSL commands.
    """

    @staticmethod
    def _run_command(cmd: List[str], input_data: Optional[bytes] = None) -> bytes:
        """Helper to run openssl commands."""
        try:
            result = subprocess.run(
                ["openssl"] + cmd,
                input=input_data,
                capture_output=True,
                check=True
            )
            return result.stdout
        except subprocess.CalledProcessError as e:
            print(f"Error running command: {' '.join(cmd)}")
            print(f"Stderr: {e.stderr.decode()}")
            raise

    # 1. Symmetric Key Generation
    @staticmethod
    def create_symmetric_key(length: int = 32, out_file: Optional[str] = None) -> bytes:
        """Generates a random symmetric key (default 256-bit)."""
        cmd = ["rand", str(length)]
        key = OpenSSLWrapper._run_command(cmd)
        if out_file:
            with open(out_file, "wb") as f:
                f.write(key)
        return key

    # 2. Asymmetric Key Generation
    @staticmethod
    def create_rsa_key(length: int = 2048, out_file: str = "rsa_private.pem") -> None:
        """Generates an RSA private key."""
        cmd = ["genrsa", "-out", out_file, str(length)]
        OpenSSLWrapper._run_command(cmd)

    @staticmethod
    def create_ec_key(curve: str = "prime256v1", out_file: str = "ec_private.pem") -> None:
        """Generates an EC private key."""
        # First generate parameters, then the key
        cmd = ["ecparam", "-name", curve, "-genkey", "-noout", "-out", out_file]
        OpenSSLWrapper._run_command(cmd)

    @staticmethod
    def extract_public_key(private_key_file: str, out_file: str) -> None:
        """Extracts public key from a private key."""
        cmd = ["pkey", "-in", private_key_file, "-pubout", "-out", out_file]
        OpenSSLWrapper._run_command(cmd)

    # 3. Hashing
    @staticmethod
    def generate_hash(file_path: str, algorithm: str = "sha256") -> str:
        """Generates a hash of a file."""
        cmd = ["dgst", f"-{algorithm}", file_path]
        output = OpenSSLWrapper._run_command(cmd).decode()
        # Output format: SHA256(file)= hash
        return output.split("=")[-1].strip()

    # 4. Sign and Verify
    @staticmethod
    def sign_document(file_path: str, private_key_file: str, signature_file: str, algorithm: str = "sha256") -> None:
        """Signs a document using a private key."""
        cmd = ["dgst", f"-{algorithm}", "-sign", private_key_file, "-out", signature_file, file_path]
        OpenSSLWrapper._run_command(cmd)

    @staticmethod
    def verify_signature(file_path: str, public_key_file: str, signature_file: str, algorithm: str = "sha256") -> bool:
        """Verifies a signature using a public key."""
        cmd = ["dgst", f"-{algorithm}", "-verify", public_key_file, "-signature", signature_file, file_path]
        try:
            output = OpenSSLWrapper._run_command(cmd).decode()
            return "Verified OK" in output
        except Exception:
            return False

    # 5. Certificates and CA Management
    @staticmethod
    def create_ca(ca_dir: str = "my_ca", common_name: str = "My Local CA") -> None:
        """Sets up a local CA structure and root certificate."""
        if os.path.exists(ca_dir):
            shutil.rmtree(ca_dir)
        
        os.makedirs(os.path.join(ca_dir, "certs"))
        os.makedirs(os.path.join(ca_dir, "crl"))
        os.makedirs(os.path.join(ca_dir, "newcerts"))
        os.makedirs(os.path.join(ca_dir, "private"))
        
        with open(os.path.join(ca_dir, "index.txt"), "w") as f:
            pass
        with open(os.path.join(ca_dir, "serial"), "w") as f:
            f.write("1000")

        # Create CA private key
        ca_key = os.path.join(ca_dir, "private", "ca.key.pem")
        OpenSSLWrapper.create_rsa_key(4096, ca_key)

        # Create CA root certificate
        ca_cert = os.path.join(ca_dir, "certs", "ca.cert.pem")
        subj = f"/C=US/ST=State/L=City/O=Org/OU=Unit/CN={common_name}"
        cmd = [
            "req", "-config", "openssl.cnf", "-key", ca_key,
            "-new", "-x509", "-days", "7300", "-sha256", "-extensions", "v3_ca",
            "-out", ca_cert, "-subj", subj
        ]
        
        # Need a basic openssl.cnf for the CA to work easily
        OpenSSLWrapper._create_default_cnf(ca_dir)
        OpenSSLWrapper._run_command(cmd)

    @staticmethod
    def _create_default_cnf(ca_dir: str):
        """Creates a minimal openssl.cnf for CA operations."""
        cnf_content = f"""
[ ca ]
default_ca = CA_default

[ CA_default ]
dir               = {os.path.abspath(ca_dir)}
certs             = $dir/certs
crl_dir           = $dir/crl
new_certs_dir     = $dir/newcerts
database          = $dir/index.txt
serial            = $dir/serial
RANDFILE          = $dir/private/.rand

private_key       = $dir/private/ca.key.pem
certificate       = $dir/certs/ca.cert.pem

default_md        = sha256

policy            = policy_loose

[ policy_loose ]
countryName             = optional
stateOrProvinceName     = optional
localityName            = optional
organizationName        = optional
organizationalUnitName  = optional
commonName              = supplied
emailAddress            = optional

[ req ]
distinguished_name = req_distinguished_name
x509_extensions    = v3_ca

[ req_distinguished_name ]
commonName = Common Name

[ v3_ca ]
subjectKeyIdentifier = hash
authorityKeyIdentifier = keyid:always,issuer
basicConstraints = critical, CA:true
keyUsage = critical, digitalSignature, cRLSign, keyCertSign
"""
        with open("openssl.cnf", "w") as f:
            f.write(cnf_content)

    @staticmethod
    def create_certificate_request(key_file: str, csr_file: str, common_name: str) -> None:
        """Creates a Certificate Signing Request (CSR)."""
        subj = f"/C=US/ST=State/L=City/O=Org/OU=Unit/CN={common_name}"
        cmd = ["req", "-new", "-key", key_file, "-out", csr_file, "-subj", subj]
        OpenSSLWrapper._run_command(cmd)

    @staticmethod
    def sign_certificate(ca_dir: str, csr_file: str, cert_file: str) -> None:
        """Signs a CSR with the local CA."""
        cmd = [
            "ca", "-config", "openssl.cnf", "-batch",
            "-in", csr_file, "-out", cert_file, "-days", "375", "-notext", "-md", "sha256"
        ]
        OpenSSLWrapper._run_command(cmd)

    @staticmethod
    def show_certificate(cert_file: str) -> str:
        """Shows certificate details."""
        cmd = ["x509", "-in", cert_file, "-text", "-noout"]
        return OpenSSLWrapper._run_command(cmd).decode()

    @staticmethod
    def envelop_p12(cert_file: str, key_file: str, p12_file: str, password: str = "password") -> None:
        """Envelops certificate and key in a PKCS#12 (PFX) packet."""
        cmd = [
            "pkcs12", "-export", "-out", p12_file, "-inkey", key_file,
            "-in", cert_file, "-passout", f"pass:{password}"
        ]
        OpenSSLWrapper._run_command(cmd)

    @staticmethod
    def envelop_signature_pkcs7(file_path: str, cert_file: str, key_file: str, out_p7_file: str) -> None:
        """Envelops a signature in a PKCS#7 (S/MIME) structure."""
        cmd = ["cms", "-sign", "-in", file_path, "-signer", cert_file, "-inkey", key_file, "-out", out_p7_file, "-outform", "DER"]
        OpenSSLWrapper._run_command(cmd)

    @staticmethod
    def verify_pkcs7_signature(p7_file: str, content_file: Optional[str] = None, ca_file: Optional[str] = None) -> bool:
        """Verifies a PKCS#7 signature."""
        cmd = ["cms", "-verify", "-in", p7_file, "-inform", "DER"]
        if content_file:
            cmd += ["-content", content_file]
        if ca_file:
            cmd += ["-CAfile", ca_file]
        else:
            cmd += ["-noverify"] # Skip certificate chain validation for simplicity if CA not provided
        
        try:
            OpenSSLWrapper._run_command(cmd)
            return True
        except Exception:
            return False
        
    # 8. Encryption and Decryption (Aggiunto da commands-openssl)
    @staticmethod
    def encrypt_file(in_file: str, out_file: str, password: str) -> None:
        """Encrypts a file using AES-128-CBC with PBKDF2."""
        cmd = [
            "enc", "-aes-128-cbc", "-pbkdf2",
            "-in", in_file, "-out", out_file,
            "-pass", f"pass:{password}"
        ]
        OpenSSLWrapper._run_command(cmd)

    @staticmethod
    def decrypt_file(in_file: str, out_file: str, password: str) -> None:
        """Decrypts a file using AES-128-CBC with PBKDF2."""
        cmd = [
            "enc", "-aes-128-cbc", "-pbkdf2", "-d",
            "-in", in_file, "-out", out_file,
            "-pass", f"pass:{password}"
        ]
        OpenSSLWrapper._run_command(cmd)

def main():
    print("--- Starting OpenSSL Wrapper API Tests ---")
    
    # 1. Symmetric Key
    print("\n1. Generating symmetric key...")
    sym_key = OpenSSLWrapper.create_symmetric_key(32, "secret.key")
    print(f"Generated 256-bit key: {sym_key.hex()}")

    # 2. Asymmetric Keys
    print("\n2. Generating RSA and EC keys...")
    OpenSSLWrapper.create_rsa_key(2048, "alice_rsa.pem")
    OpenSSLWrapper.extract_public_key("alice_rsa.pem", "alice_rsa_pub.pem")
    
    OpenSSLWrapper.create_ec_key("prime256v1", "bob_ec.pem")
    OpenSSLWrapper.extract_public_key("bob_ec.pem", "bob_ec_pub.pem")
    print("Keys generated.")

    # 3. Hashing
    print("\n3. Hashing a document...")
    with open("document.txt", "w") as f:
        f.write("This is a secret message.")
    
    sha256_hash = OpenSSLWrapper.generate_hash("document.txt", "sha256")
    sha512_hash = OpenSSLWrapper.generate_hash("document.txt", "sha512")
    print(f"SHA256: {sha256_hash}")
    print(f"SHA512: {sha512_hash}")

    # 4. Sign and Verify (Raw/Detached)
    print("\n4. Signing and Verifying with RSA (detached)...")
    OpenSSLWrapper.sign_document("document.txt", "alice_rsa.pem", "signature.bin")
    is_valid = OpenSSLWrapper.verify_signature("document.txt", "alice_rsa_pub.pem", "signature.bin")
    print(f"Signature valid: {is_valid}")

    # 5. CA and Certificates
    print("\n5. CA and Certificate Management...")
    OpenSSLWrapper.create_ca("local_ca", "My Local Root CA")
    
    # Create user key and CSR
    OpenSSLWrapper.create_rsa_key(2048, "user.key")
    OpenSSLWrapper.create_certificate_request("user.key", "user.csr", "Alice User")
    
    # Sign user cert with CA
    OpenSSLWrapper.sign_certificate("local_ca", "user.csr", "user.crt")
    print("User certificate signed by CA.")
    
    # Show cert
    cert_details = OpenSSLWrapper.show_certificate("user.crt")
    print("Certificate Details (snippet):")
    print("\n".join(cert_details.splitlines()[:10]))

    # 6. PKCS#7 Enveloped Signature
    print("\n6. Enveloping signature in PKCS#7...")
    OpenSSLWrapper.envelop_signature_pkcs7("document.txt", "user.crt", "user.key", "signature.p7m")
    is_p7_valid = OpenSSLWrapper.verify_pkcs7_signature("signature.p7m", "document.txt", "local_ca/certs/ca.cert.pem")
    print(f"PKCS#7 Signature valid: {is_p7_valid}")

    # 7. PKCS#12 Enveloping
    print("\n7. Enveloping in PKCS#12...")
    OpenSSLWrapper.envelop_p12("user.crt", "user.key", "user.p12", "mysecret")
    print("Created user.p12")

    print("\n--- All tests completed successfully ---")

if __name__ == "__main__":
    main()
